const config = {
  chain: {
    name: "shibuya",
    prefix: 5,
  },
  typesBundle: "shibuya",
  batchSize: 500,
  blockRange: {
    from: 0,
  },
};

export default config;
