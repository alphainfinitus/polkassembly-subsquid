export enum VoteType {
    Referendum = "Referendum",
    Motion = "Motion",
    DemocracyProposal = "DemocracyProposal",
}
