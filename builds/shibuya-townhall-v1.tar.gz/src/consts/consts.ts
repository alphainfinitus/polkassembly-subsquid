export const NOTIFICATION_URL = "https://us-central1-polkasafe-a8042.cloudfunctions.net/notify";
